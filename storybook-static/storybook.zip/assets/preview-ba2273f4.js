const e={parameters:{actions:{argTypesRegex:"^on[A-Z].*"},controls:{matchers:{color:/(background|color)$/i,date:/Date$/i}}}};export{e as default};
//# sourceMappingURL=preview-ba2273f4.js.map
