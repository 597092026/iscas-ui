import{S as s,c,s as l}from"./index-6dced412.js";import"./iframe-1a055cf6.js";import"../sb-preview/runtime.js";import"./_commonjsHelpers-725317a4.js";import"./index-d37d4223.js";import"./index-cd97d88f.js";import"./index-356e4a49.js";export{s as SyntaxHighlighter,c as createCopyToClipboardFunction,l as default};
//# sourceMappingURL=syntaxhighlighter-NMPM6SWI-2ec4860c.js.map
